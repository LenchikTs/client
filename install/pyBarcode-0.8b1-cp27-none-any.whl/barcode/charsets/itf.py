# -*- coding: utf-8 -*-

from __future__ import unicode_literals

# W = Wide bar
# w = wide space
# N = Narrow bar
# n = narrow space

START = 'NnNn'
STOP = 'WnN'
CODES = ('NNWWN', 'WNNNW', 'NWNNW', 'WWNNN', 'NNWNW', 'WNWNN', 'NWWNN', 'NNNWW', 'WNNWN', 'NWNWN')
